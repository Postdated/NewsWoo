<?php
/**
 * WooCommerce REST API
 *
 * Adds Name Your Price data to the WooCommerce REST API.
 *
 * @package  WooCommerce Name Your Price Products/REST API
 * @since    3.6.0
 * @version  3.6.1
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC_NYP_REST_API Class.
 */
class WC_NYP_REST_API {

	/**
	 * Setup API class.
	 *
	 * @return object
	 */
	public static function init() {

		// Register WP REST API custom product fields.
		add_filter( 'woocommerce_rest_product_schema', array( __CLASS__, 'filter_product_schema' ) );
		add_filter( 'woocommerce_rest_prepare_product_object', array( __CLASS__, 'prepare_product_response' ), 10, 3 );
		add_filter( 'woocommerce_rest_pre_insert_product_object', array( __CLASS__, 'prepare_insert_product' ), 10, 2 );
	}

	/*
	|--------------------------------------------------------------------------
	| Products.
	|--------------------------------------------------------------------------
	*/

	/**
	 * Filter the data for a response.
	 *
	 * The dynamic portion of the hook name, $this->post_type,
	 * refers to object type being prepared for the response.
	 *
	 * @param array $schema Schema array.
	 * @return array
	 */
	public static function filter_product_schema( $schema ) {
		return array_merge(
			$schema,
			array(
				'nyp'                 => array(
					'description' => esc_html__( 'Customers are allowed to determine their own price.', 'wc_name_your_price' ),
					'type'        => 'boolean',
					'context'     => array( 'view', 'edit' ),
				),
				'nyp_suggested_price' => array(
					'description' => esc_html__( 'Suggested Price', 'wc_name_your_price' ),
					'type'        => 'string',
					'context'     => array( 'view', 'edit' ),
				),
				'nyp_minimum_price'   => array(
					'description' => esc_html__( 'Minimum Price', 'wc_name_your_price' ),
					'type'        => 'string',
					'context'     => array( 'view', 'edit' ),
				),
				'nyp_maximum_price'   => array(
					'description' => esc_html__( 'Maximum Price', 'wc_name_your_price' ),
					'type'        => 'string',
					'context'     => array( 'view', 'edit' ),
				),
				'nyp_hide_minimum'    => array(
					'description' => esc_html__( 'Hide Minimum Price on frontend.', 'wc_name_your_price' ),
					'type'        => 'boolean',
					'context'     => array( 'view', 'edit' ),
				),
			)
		);
	}


	/**
	 * Filter the data for a response.
	 *
	 * The dynamic portion of the hook name, $this->post_type,
	 * refers to object type being prepared for the response.
	 *
	 * @param WP_REST_Response $response The response object.
	 * @param WC_Product     $product  Product object.
	 * @return WP_REST_Response $response The response object.
	 */
	public static function prepare_product_response( $response, $product ) {

		$data = $response->get_data();

		if ( WC_Name_Your_Price_Helpers::is_nyp( $product ) ) {
			$data['nyp']                 = true;
			$data['nyp_suggested_price'] = WC_Name_Your_Price_Helpers::get_suggested_price( $product );
			$data['nyp_minimum_price']   = WC_Name_Your_Price_Helpers::get_minimum_price( $product );
			$data['nyp_maximum_price']   = WC_Name_Your_Price_Helpers::get_maximum_price( $product );
			$data['nyp_hide_minimum']    = WC_Name_Your_Price_Helpers::is_minimum_hidden( $product );
		} else {
			$data['nyp']                 = false;
			$data['nyp_suggested_price'] = '';
			$data['nyp_minimum_price']   = '';
			$data['nyp_maximum_price']   = '';
			$data['nyp_hide_minimum']    = '';
		}

		$response->set_data( $data );

		return $response;
	}

	/**
	 * Filters an object before it is inserted via the REST API.
	 *
	 * @param WC_Product     $product  Product object.
	 * @param WP_REST_Request $request  Request object.
	 * @return WC_Product     $product  Product object.
	 */

	public static function prepare_insert_product( $product, $request ) {

		if ( ! $product->is_type( WC_Name_Your_Price_Helpers::get_simple_supported_types() ) ) {
			return $product;
		}

		// Only update NYP state if explicitly declared in payload.
		if ( isset( $request['nyp'] ) ) {
			$product->update_meta_data( '_nyp', wc_bool_to_string( $request['nyp'] ) );
		}

		// Suggested price.
		if ( isset( $request['nyp_suggested_price'] ) ) {
			$suggested = '' !== trim( $request['nyp_suggested_price'] ) ? wc_format_decimal( wc_clean( wp_unslash( $request['nyp_suggested_price'] ) ) ) : '';
			$product->update_meta_data( '_suggested_price', $suggested );
		} else {
			$suggested = '';
		}

		// Minimum price.
		if ( isset( $request['nyp_minimum_price'] ) ) {
			$minimum = '' !== trim( $request['nyp_minimum_price'] ) ? wc_format_decimal( wc_clean( wp_unslash( $request['nyp_minimum_price'] ) ) ) : '';
			$product->update_meta_data( '_min_price', $minimum );
		} else {
			$minimum = '';
		}

		// Show error if minimum price is higher than the suggested price.
		if ( $suggested && $minimum && $minimum > $suggested ) {
			return new WP_Error( 'woocommerce_rest_product_nyp_invalid_minimum_price', esc_html__( 'The suggested price must be higher than the minimum for Name Your Price products. Please review your prices.', 'wc_name_your_price' ), array( 'status' => 404 ) );
		}

		// Set the regular price to enable WC to sort by price.
		if ( 'yes' === $product->get_meta( '_nyp', true ) ) {

			$product->set_sale_price( '' );
			$product->delete_meta_data( '_has_nyp' );

			// Sort by minimum by default, with option to sort by suggested price.
			$sort_price = apply_filters( 'wc_nyp_sort_by_suggested_price', false, $product ) ? $suggested : $minimum;

			/**
			 * If nothing is entered for min/suggested, we should still set the _price as 0
			 * This will resolve PHP notices for cart subtotals for items that are bundled, but not priced-individually.
			 *
			 * @see: https://github.com/woocommerce/woocommerce-product-bundles/issues/875
			 */
			if ( '' === $sort_price ) {
				$sort_price = 0;
			}

			$product->set_price( $sort_price );
			$product->set_regular_price( $sort_price );
			$product->set_sale_price( '' );

			if ( $product->is_type( 'subscription' ) ) {
				$product->update_meta_data( '_subscription_price', $sort_price );
			}
		}

		// Maximum price.
		if ( isset( $request['nyp_maximum_price'] ) ) {
			$maximum = '' !== trim( $request['nyp_maximum_price'] ) ? wc_format_decimal( wc_clean( wp_unslash( $request['nyp_maximum_price'] ) ) ) : '';
			$product->update_meta_data( '_maximum_price', $maximum );
		} else {
			$maximum = '';
		}

		// Show error if minimum price is higher than the maximum price.
		if ( $maximum && $minimum && $minimum > $maximum ) {
			return new WP_Error( 'woocommerce_rest_product_nyp_invalid_maximum_price', esc_html__( 'The maximum price must be higher than the minimum for Name Your Price products. Please review your prices.', 'wc_name_your_price' ), array( 'status' => 404 ) );
		}

		// Hide minimum price.
		if ( isset( $request['nyp_hide_minimum'] ) ) {
			$hide = wc_bool_to_string( $request['nyp_hide_minimum'] );
			$product->update_meta_data( '_hide_nyp_minimum', $hide );
		}

		return $product;
	}
}
WC_NYP_REST_API::init();
