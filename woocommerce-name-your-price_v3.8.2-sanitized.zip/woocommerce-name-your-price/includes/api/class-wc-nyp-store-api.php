<?php
/**
 * WC_NYP_Store_API class
 *
 * @package  WooCommerce Name Your Price/REST API
 * @since    3.5.0
 * @version  3.8.1
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\StoreApi\StoreApi;
use Automattic\WooCommerce\StoreApi\Exceptions\InvalidCartException;
use Automattic\WooCommerce\StoreApi\Exceptions\RouteException;
use Automattic\WooCommerce\StoreApi\Schemas\V1\ProductSchema;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema;
use Automattic\WooCommerce\StoreApi\Schemas\ExtendSchema;
use Automattic\WooCommerce\StoreApi\SchemaController;

/**
 * Extends the store public API with NYP-related data for each product.
 */
class WC_NYP_Store_API {

	/**
	 * Plugin Identifier, unique to each plugin.
	 *
	 * @var string
	 */
	const IDENTIFIER = 'name_your_price';

	/**
	 * Bootstraps the class and hooks required data.
	 */
	public static function init() {

		self::extend_store();

		// Filter cart item response.
		add_filter( 'rest_request_after_callbacks', array( __CLASS__, 'filter_cart_item_data' ), 10, 3 );
		add_filter( 'woocommerce_hydration_request_after_callbacks', array( __CLASS__, 'filter_cart_item_data' ), 10, 3 );

		// Register custom configuration data.
		add_filter( 'woocommerce_store_api_add_to_cart_data', array( __CLASS__, 'add_to_cart_data' ), 10, 2 );

		// Validate add to cart in the Store API and add cart errors.
		add_action( 'woocommerce_store_api_validate_add_to_cart', array( __CLASS__, 'validate_add_to_cart_item' ), 10, 2 );

		// Re-validate product in cart in the Store API and add cart errors.
		add_action( 'woocommerce_store_api_validate_cart_item', array( __CLASS__, 'validate_cart_item' ), 10, 2 );
	}

	/*
	|--------------------------------------------------------------------------
	| Callbacks.
	|--------------------------------------------------------------------------
	*/

	/**
	 * Registers the actual data into each endpoint.
	 */
	private static function extend_store() {

		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			return;
		}

		// Extend Regular Product Data.
		woocommerce_store_api_register_endpoint_data(
			array(
				'endpoint'        => ProductSchema::IDENTIFIER,
				'namespace'       => self::IDENTIFIER,
				'data_callback'   => array( __CLASS__, 'extend_product_data' ),
				'schema_callback' => array( __CLASS__, 'extend_product_schema' ),
				'schema_type'     => ARRAY_A,
			)
		);

		// Extend Cart Item Data.
		woocommerce_store_api_register_endpoint_data(
			array(
				'endpoint'        => CartItemSchema::IDENTIFIER,
				'namespace'       => self::IDENTIFIER,
				'data_callback'   => array( __CLASS__, 'extend_cart_item_data' ),
				'schema_callback' => array( __CLASS__, 'extend_cart_item_schema' ),
				'schema_type'     => ARRAY_A,
			)
		);
	}

	/**
	 * ---------------------------------------------------------------------------------
	 * Product Data
	 * ---------------------------------------------------------------------------------
	 */

	/**
	 * Register additional product data into product endpoint.
	 *
	 * @since 3.7.0
	 *
	 * @param WC_Product  $product
	 * @return array $item_data
	 */
	public static function extend_product_data( $product ) {

		$item_data = array();

		if ( WC_Name_Your_Price_Helpers::is_nyp( $product ) ) {

			$item_data['is_nyp']       = true;
			$item_data['hide_minimum'] = WC_Name_Your_Price_Helpers::is_minimum_hidden( $product );

			$extend = StoreApi::container()->get( ExtendSchema::class );

			$suggested_price = WC_Name_Your_Price_Helpers::get_suggested_price( $product );
			$minimum_price   = WC_Name_Your_Price_Helpers::get_minimum_price( $product );
			$maximum_price   = WC_Name_Your_Price_Helpers::get_maximum_price( $product );

			$nyp_price_response = $extend->get_formatter( 'currency' )->format(
				array(
					'suggested_price' => $suggested_price ? $extend->get_formatter( 'money' )->format(
						$suggested_price,
						array(
							'rounding_mode' => PHP_ROUND_HALF_DOWN,
							'decimals'      => wc_get_price_decimals(),
						)
					) : null,
					'minimum_price'   => $minimum_price ? $extend->get_formatter( 'money' )->format(
						$minimum_price,
						array(
							'rounding_mode' => PHP_ROUND_HALF_DOWN,
							'decimals'      => wc_get_price_decimals(),
						)
					) : 0,
					'maximum_price'   => $maximum_price ? $extend->get_formatter( 'money' )->format(
						$maximum_price,
						array(
							'rounding_mode' => PHP_ROUND_HALF_DOWN,
							'decimals'      => wc_get_price_decimals(),
						)
					) : null,
				)
			);

			$item_data['prices'] = $nyp_price_response;

		}

		return $item_data;
	}

	/**
	 * Register schema into product endpoint.
	 *
	 * @since 3.7.0
	 *
	 * @return array Registered schema.
	 */
	public static function extend_product_schema() {

		// $currency_schema = StoreApi::container()->get( SchemaController::class )->get( ProductSchema::IDENTIFIER )->get_properties()['prices']['properties'];
		$currency_schema = array();

		return array(
			'is_nyp'       => array(
				'description' => esc_html__( 'Customers are allowed to determine their own price.', 'wc_name_your_price' ),
				'type'        => 'boolean',
				'context'     => array( 'view' ),
				'readonly'    => true,
			),
			'hide_minimum' => array(
				'description' => esc_html__( 'Hide minimum price.', 'wc_name_your_price' ),
				'type'        => 'boolean',
				'context'     => array( 'view' ),
				'readonly'    => true,
			),
			'prices'       => array(
				'description' => esc_html__( 'Name your price custom price data provided using the smallest unit of the currency entered price', 'wc_name_your_price' ),
				'type'        => 'object',
				'context'     => array( 'view', 'edit' ),
				'readonly'    => true,
				'properties'  => array_merge(
					$currency_schema,
					array(
						'suggested_price' => array(
							'description' => esc_html__( 'Suggested price for product.', 'wc_name_your_price' ),
							'type'        => array( 'string', null ),
							'context'     => array( 'view', 'edit' ),
							'readonly'    => true,
						),
						'minimum_price'   => array(
							'description' => esc_html__( 'Lowest acceptable price for product.', 'wc_name_your_price' ),
							'type'        => 'string',
							'context'     => array( 'view', 'edit' ),
							'readonly'    => true,
						),
						'maximum_price'   => array(
							'description' => esc_html__( 'Highest acceptable price for product.', 'wc_name_your_price' ),
							'type'        => array( 'string', 'null' ),
							'context'     => array( 'view', 'edit' ),
							'readonly'    => true,
						),
					)
				),
			),
		);
	}

	/*
	|--------------------------------------------------------------------------
	| Cart Item Functions.
	|--------------------------------------------------------------------------
	*/

	/**
	 * Register data into cart/items endpoint.
	 *
	 * @param array  $cart_item
	 * @return array $item_data
	 */
	public static function extend_cart_item_data( $cart_item ) {

		$item_data = array();

		if ( isset( $cart_item['nyp'] ) ) {

			$extend = StoreApi::container()->get( ExtendSchema::class );

			$nyp_price = $extend->get_formatter( 'money' )->format(
				$cart_item['nyp'],
				array(
					'rounding_mode' => PHP_ROUND_HALF_DOWN,
					'decimals'      => wc_get_price_decimals(),
				)
			);

			$item_data = $extend->get_formatter( 'currency' )->format(
				array(
					'nyp' => $nyp_price,
				)
			);

		}

		return $item_data;
	}

	/**
	 * Register schema into cart/items endpoint.
	 *
	 * @return array Registered schema.
	 */
	public static function extend_cart_item_schema() {

		$currency_schema = StoreApi::container()->get( SchemaController::class )->get( ProductSchema::IDENTIFIER )->get_store_currency_properties();

		return array_merge(
			$currency_schema,
			array(
				'nyp' => array(
					'description' => __( 'Name your price custom price data provided using the smallest unit of the currency entered price.', 'wc_name_your_price' ),
					'type'        => 'string',
					'context'     => array( 'view', 'edit' ),
					'readonly'    => true,
				),
			)
		);
	}

	/**
	 * Pass price config in Store API context.
	 *
	 * @throws RouteException
	 *
	 * @param  array  $add_to_cart_data
	 * @param array   $request Add to cart request params including id, quantity, and variation attributes.
	 */
	public static function add_to_cart_data( $add_to_cart_data, \WP_REST_Request $request ) {

		if ( isset( $request['nyp'] ) ) {
			$add_to_cart_data['cart_item_data']['nyp'] = WC_Name_Your_Price_Helpers::standardize_number( $request['nyp'] );
		}

		return $add_to_cart_data;
	}

	/**
	 * Filter store API responses to:
	 *
	 * - Add edit price button
	 *
	 * @since 3.5.9
	 *
	 * @param WP_REST_Response|WP_HTTP_Response|WP_Error|mixed $response Result to send to the client.
	 *                                                                   Usually a WP_REST_Response or WP_Error.
	 * @param array                                            $handler  Route handler used for the request.
	 * @param WP_REST_Request                                  $request  Request used to generate the response.
	 * @return WP_REST_Response
	 */
	public static function filter_cart_item_data( $response, $handler, $request ) {

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( strpos( $request->get_route(), 'wc/store' ) === false ) {
			return $response;
		}

		$data = $response->get_data();

		if ( empty( $data['items'] ) ) {
			return $response;
		}

		if ( ! WC()->cart ) {
			return $response;
		}

		$cart = WC()->cart->get_cart();

		foreach ( $data['items'] as &$item_data ) {

			$cart_item_key = $item_data['key'];
			$cart_item     = isset( $cart[ $cart_item_key ] ) ? $cart[ $cart_item_key ] : null;

			if ( is_null( $cart_item ) ) {
				continue;
			}

			if ( isset( $cart_item['nyp'] ) ) {
				self::filter_container_cart_item_short_description( $item_data, $cart_item );
			}
		}

		$response->set_data( $data );

		return $response;
	}

	/**
	 * Validate price in Store API context.
	 *
	 * @throws RouteException
	 *
	 * @param  WC_Product  $product
	 * @param array       $request Add to cart request params including id, quantity, and variation attributes.
	 */
	public static function validate_add_to_cart_item( $product, $request ) {

		if ( WC_Name_Your_Price_Helpers::is_nyp( $product ) ) {

			$price    = isset( $request['cart_item_data'] ) && isset( $request['cart_item_data']['nyp'] ) ? $request['cart_item_data']['nyp'] : '';
			$quantity = isset( $request['quantity'] ) ? intval( $request['quantity'] ) : 1;

			// Validate.
			try {

				WC_Name_Your_Price()->cart->validate_price( $product, $quantity, $price, '', array( 'throw_exception' => true ) );

			} catch ( Exception $e ) {

				if ( $e->getMessage() ) {

					// phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
					throw new RouteException(
						'woocommerce_store_api_invalid_product_price',
						html_entity_decode( wp_strip_all_tags( $e->getMessage() ), ENT_QUOTES, get_bloginfo( 'charset' ) ),
						500
					);
					// phpcs:enable WordPress.Security.EscapeOutput.ExceptionNotEscaped
				}
			}
		}
	}


	/**
	 * Validate price in Store API cart context.
	 * Prevent access to checkout if something got messed up.
	 *
	 * @param \WC_Product $product Product object being added to the cart.
	 * @param array       $cart_item Cart item array.
	 * @throws InvalidCartException If validation fails.
	 */
	public static function validate_cart_item( $product, $cart_item ) {

		if ( WC_Name_Your_Price_Helpers::is_nyp( $product ) ) {

			$price    = isset( $cart_item['nyp'] ) ? $cart_item['nyp'] : '';
			$quantity = isset( $cart_item['quantity'] ) ? intval( $cart_item['quantity'] ) : 1;

			// Validate.
			try {

				WC_Name_Your_Price()->cart->validate_price(
					$product,
					$quantity,
					$price,
					'',
					array(
						'context'         => 'cart',
						'throw_exception' => true,
					)
				);

			} catch ( Exception $e ) {

				if ( $e->getMessage() ) {

					// translators: %1$s is the product title. %2$s is the reason it cannot be purchased.
					$notice = sprintf( wp_kses_post( __( '&quot;%1$s&quot; cannot be purchased. %2$s', 'wc_name_your_price' ) ), $product->get_title(), wp_strip_all_tags( $e->getMessage() ) );

					$cart_errors = new WP_Error( 'woocommerce_store_api_invalid_product_price', html_entity_decode( $notice, ENT_QUOTES, get_bloginfo( 'charset' ) ) );

					// phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped
					throw new InvalidCartException(
						'woocommerce_cart_error',
						$cart_errors,
						409
					);
					// phpcs:enable WordPress.Security.EscapeOutput.ExceptionNotEscaped
				}
			}
		}
	}

	/**
	 * Filter cart item short description to support cart editing.
	 *
	 * @since 3.5.9
	 *
	 * @param array  $item_data
	 * @param array  $cart_item
	 */
	private static function filter_container_cart_item_short_description( &$item_data, $cart_item ) {

		$show_edit_link = wc_string_to_bool( get_option( 'woocommerce_nyp_edit_in_cart', 'yes' ) === 'yes' );

		if ( isset( $cart_item['nyp'] ) && apply_filters( 'wc_nyp_show_edit_link_in_cart', $show_edit_link, $cart_item, $cart_item['key'] ) ) {

			$trimmed_short_description = '';

			if ( $item_data['short_description'] ) {
				$trimmed_short_description = '<p class="wc-block-components-product-metadata__description-text">' . wp_trim_words( $item_data['short_description'], 12 ) . '</p>';
			}

			// Get the Edit URL.
			$edit_in_cart_link = WC_Name_Your_Price_Helpers::get_edit_url( $cart_item );

			// Add button to end of short description response.
			$item_data['short_description'] = '<p class="wc-block-cart-item__edit"><a class="components-button wc-block-components-button ' . esc_attr( wp_theme_get_element_class_name( 'button' ) ) . ' outlined wc-block-cart-item__edit-link outlined" role="button" href="' . esc_url( $edit_in_cart_link ) . '"><span class="wc-block-components-button__text">' . esc_html_x( 'Edit price', 'edit in cart link text', 'wc_name_your_price' ) . '</span></a></p>' . $trimmed_short_description;
		}
	}
}
WC_NYP_Store_API::init();
