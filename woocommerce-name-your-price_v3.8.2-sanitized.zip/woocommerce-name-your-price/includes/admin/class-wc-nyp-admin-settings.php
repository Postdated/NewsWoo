<?php
/**
 * WooCommerce Name Your Price Settings
 *
 * @package     WC_Name_Your_Price/Admin
 * @since       2.0.0
 * @version     3.8.2
 */
use Automattic\WooCommerce\Admin\Settings\LegacySettingsPageAdapter;
use Automattic\WooCommerce\Admin\Settings\SettingsUIPageInterface;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Settings for API.
 */
if ( class_exists( 'WC_NYP_Admin_Settings', false ) ) {
	return new WC_NYP_Admin_Settings();
}

/**
 * WC_NYP_Admin_Settings
 */
class WC_NYP_Admin_Settings extends WC_Settings_Page {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id    = 'nyp';
		$this->label = esc_html__( 'Name Your Price', 'wc_name_your_price' );

		add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_settings_page' ), 20 );
		add_action( 'woocommerce_settings_' . $this->id, array( $this, 'output' ) );
		add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );

		parent::__construct();
	}


	/**
	 * Get the native Settings UI page for this registered section.
	 *
	 * @since 3.8.2
	 *
	 * @param \WC_Settings_Page $parent_page Parent settings page.
	 * @return SettingsUIPageInterface|null
	 */
	public function get_settings_ui_page(): ?SettingsUIPageInterface {
		return new LegacySettingsPageAdapter( $this );
	}

	/**
	 * Get settings array
	 *
	 * @return array
	 */
	public function get_settings() {

		return apply_filters(
			'wc_' . $this->id . '_settings',
			array(

				array(
					'title' => esc_html__( 'Text strings', 'wc_name_your_price' ),
					'type'  => 'title',
					'desc'  => esc_html__( 'Modify the text strings used by the Name Your Own Price extension.', 'wc_name_your_price' ),
					'id'    => 'woocommerce_nyp_options',
				),

				array(
					'title'    => esc_html__( 'Suggested Price Text', 'wc_name_your_price' ),
					'desc'     => esc_html__( 'This is the text to display before the suggested price. You can use the placeholder %PRICE% to display the suggested price.', 'wc_name_your_price' ),
					'id'       => 'woocommerce_nyp_suggested_text',
					'type'     => 'text',
					'css'      => 'min-width:300px;',
					'default'  => _x( 'Suggested price: %PRICE%', 'Name your price default suggested text', 'wc_name_your_price' ),
					'desc_tip' => true,
				),

				array(
					'title'    => esc_html__( 'Minimum Price Text', 'wc_name_your_price' ),
					'desc'     => esc_html__( 'This is the text to display before the minimum accepted price. You can use the placeholder %PRICE% to display the minimum price.', 'wc_name_your_price' ),
					'id'       => 'woocommerce_nyp_minimum_text',
					'type'     => 'text',
					'css'      => 'min-width:300px;',
					'default'  => _x( 'Minimum price: %PRICE%', 'Name your price default suggested text', 'wc_name_your_price' ),
					'desc_tip' => true,
				),

				array(
					'title'    => esc_html__( 'Name Your Price Text', 'wc_name_your_price' ),
					'desc'     => esc_html__( 'This is the text that appears above the Name Your Price input field.', 'wc_name_your_price' ),
					'id'       => 'woocommerce_nyp_label_text',
					'type'     => 'text',
					'css'      => 'min-width:300px;',
					'default'  => esc_html__( 'Name your price', 'wc_name_your_price' ),
					'desc_tip' => true,
				),

				array(
					'title'       => esc_html__( 'Add to Cart Button Text for Shop', 'wc_name_your_price' ),
					'desc'        => esc_html__( 'This is the text that appears on the Add to Cart buttons on the Shop Pages.', 'wc_name_your_price' ),
					'id'          => 'woocommerce_nyp_button_text',
					'type'        => 'text',
					'css'         => 'min-width:300px;',
					'default'     => esc_html__( 'Choose price', 'wc_name_your_price' ),
					'placeholder' => esc_html__( 'Choose price', 'wc_name_your_price' ),
					'desc_tip'    => true,
				),

				array(
					'title'    => esc_html__( 'Add to Cart Button Text for Single Product', 'wc_name_your_price' ),
					'desc'     => esc_html__( 'This is the text that appears on the Add to Cart buttons on the Single Product Pages. Leave blank to inherit the default add to cart text.', 'wc_name_your_price' ),
					'id'       => 'woocommerce_nyp_button_text_single',
					'type'     => 'text',
					'css'      => 'min-width:300px;',
					'default'  => '',
					'desc_tip' => true,
				),

				array(
					'type' => 'sectionend',
					'id'   => 'woocommerce_nyp_options',
				),

				array(
					'title' => esc_html__( 'Styles', 'wc_name_your_price' ),
					'type'  => 'title',
					'id'    => 'woocommerce_nyp_style_options',
				),

				array(
					'title'   => esc_html__( 'Disable stylesheet', 'wc_name_your_price' ),
					'desc'    => esc_html__( 'Do not load the Name Your Price stylesheet.', 'wc_name_your_price' ),
					'id'      => 'woocommerce_nyp_disable_css',
					'type'    => 'checkbox',
					'default' => 'no',
				),

				array(
					'title'   => esc_html__( 'Hide quantity input', 'wc_name_your_price' ),
					'id'      => 'woocommerce_nyp_hide_quantity',
					'desc'    => esc_html__( 'Hide the quantity input for Name Your Price products.', 'wc_name_your_price' ),
					'type'    => 'checkbox',
					'default' => 'no',
				),

				array(
					'type' => 'sectionend',
					'id'   => 'woocommerce_nyp_style_options',
				),

				array(
					'title' => esc_html__( 'Advanced Options', 'wc_name_your_price' ),
					'type'  => 'title',
					'id'    => 'woocommerce_nyp_advanced_options',
				),

				array(
					'title'   => esc_html__( 'Enable edit in cart', 'wc_name_your_price' ),
					'id'      => 'woocommerce_nyp_edit_in_cart',
					'desc'    => esc_html__( 'Allow for editing price from cart.', 'wc_name_your_price' ),
					'type'    => 'checkbox',
					'default' => 'yes',
				),

				array(
					'title'   => esc_html__( 'Enable strict sold-individually', 'wc_name_your_price' ),
					'id'      => 'woocommerce_nyp_strict_sold_individually',
					'desc'    => esc_html__( 'Enforce stricter sold individually rules on Name Your Price products.', 'wc_name_your_price' ),
					'type'    => 'checkbox',
					'default' => 'no',
				),

				array(
					'type' => 'sectionend',
					'id'   => 'woocommerce_nyp_advanced_options',
				),

			)
		); // End pages settings.
	}
}
return new WC_NYP_Admin_Settings();
