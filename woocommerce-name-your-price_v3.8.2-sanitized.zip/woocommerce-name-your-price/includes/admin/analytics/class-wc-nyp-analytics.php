<?php
/**
 * WC_NYP_Analytics class
 *
 * @package  WooCommerce Name Your Price/Admin/Analytics
 * @since    4.0.0
 * @version  4.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\StoreApi\Exceptions\RouteException;
use Automattic\WooCommerce\Admin\PageController;

/**
 * Extends the store public API with NYP-related data for each product.
 */
class WC_NYP_Analytics {

	/**
	 * Plugin Identifier, unique to each plugin.
	 *
	 * @var string
	 */
	const IDENTIFIER = 'name_your_price';

	/**
	 * Bootstraps the class and hooks required data.
	 */
	public static function init() {

		add_filter( 'woocommerce_analytics_report_menu_items', array( __CLASS__, 'add_report_menu' ) );

		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'register_script' ) );
	}

	/**
	 * Add page to the menu
	 *
	 * @throws RouteException
	 *
	 * @param  array  $pages
	 * @return array
	 */
	public static function add_report_menu( $pages ): array {

		$pages[] = array(
			'id'     => 'wc-nyp',
			'title'  => __( 'Name Your Price', 'wc_name_your_price' ),
			'parent' => 'woocommerce-analytics',
			'path'   => '/analytics/nyp',
		);

		return $pages;
	}

		/**
		 * Register analytics JS.
		 */
	public static function register_script() {

		if ( ! class_exists( 'Automattic\WooCommerce\Admin\PageController' ) || ! Automattic\WooCommerce\Admin\PageController::is_admin_or_embed_page() ) {
			return;
		}

		$script_path       = '/assets/dist/admin/analytics.js';
		$script_asset_path = WC_Name_Your_Price()->plugin_path() . 'assets/dist/admin/analytics.asset.php';
		$script_asset      = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version'      => WC_Name_Your_Price()->version,
			);
		$script_url        = WC_Name_Your_Price()->plugin_url() . $script_path;

		wp_register_script(
			'wc-nyp-analytics-report',
			$script_url,
			$script_asset['dependencies'],
			WC_Name_Your_Price()->get_file_version( WC_Name_Your_Price()->plugin_path() . $script_path ),
			true
		);

		// Load JS translations.
		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( 'wc-nyp-analytics-report', 'wc_name_your_price', WC_Name_Your_Price()->plugin_path() . 'languages/' );
		}

		// Enqueue script.
		wp_enqueue_script( 'wc-nyp-analytics-report' );
	}
}
WC_NYP_Analytics::init();
