<?php
/**
 * WooCommerce Name Your Price Autoloader.
 *
 * @package WooCommerce Name Your Price\Classes
 * @version 3.8.2
 */

defined( 'ABSPATH' ) || exit;

/**
 * Autoloader class.
 */
class WC_NYP_Autoloader {

	/**
	 * Path to the includes directory.
	 *
	 * @var string
	 */
	private $include_path = '';

	/**
	 * The Constructor.
	 */
	public function __construct() {
		if ( function_exists( '__autoload' ) ) {
			spl_autoload_register( '__autoload' );
		}

		spl_autoload_register( array( $this, 'autoload' ) );

		$this->include_path = untrailingslashit( plugin_dir_path( WC_NYP_PLUGIN_FILE ) ) . '/includes/';
	}

	/**
	 * Take a class name and turn it into a file name.
	 *
	 * @param  string $class Class name.
	 * @return string
	 */
	private function get_file_name_from_class( $class ) {
		// Only allow alphanumeric and underscores.
		if ( ! preg_match( '/^wc_nyp_[a-z0-9_]+$/i', $class ) ) {
			return '';
		}
		return 'class-' . str_replace( '_', '-', $class ) . '.php';
	}

	/**
	 * Include a class file.
	 *
	 * @param  string $path File path.
	 * @return bool Successful or not.
	 */
	private function load_file( $path ) {
		if ( ! $path || ! is_readable( $path ) ) {
			return false;
		}

		// Ensure the resolved path is within the intended directory.
		$real_path = realpath( $path );
		$base_path = realpath( $this->include_path );
		
		if ( ! $real_path || ! $base_path || 0 !== strpos( $real_path, $base_path ) ) {
			return false;
		}

		include_once $real_path;
		return true;
	}

	/**
	 * Auto-load WC classes on demand to reduce memory consumption.
	 *
	 * @param string $class Class name.
	 */
	public function autoload( $class ) {
		$class = strtolower( $class );

		if ( 0 !== strpos( $class, 'wc_nyp_' ) ) {
			return;
		}

		$file = $this->get_file_name_from_class( $class );
		$path = '';

		if ( 0 === strpos( $class, 'wc_nyp_notes_' ) ) {
			$path = $this->include_path . 'admin/notes/';
		}

		if ( empty( $path ) || ! $this->load_file( $path . $file ) ) {
			$this->load_file( $this->include_path . $file );
		}
	}
}

new WC_NYP_Autoloader();
