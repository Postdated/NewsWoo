<?php
/**
 * WC_NYP_Blocks_Compatibility class
 *
 * @package  WooCommerce Name Your Price/Compatibility
 * @since    3.5.0
 * @version  3.7.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooCommerce Blocks Compatibility.
 *
 * @since 3.7.0 Doesn't do anything but is loaded for backwards compatibility.
 */
class WC_NYP_Blocks_Compatibility {

	/**
	 * Initialize.
	 */
	public static function init() {

		if ( ! did_action( 'woocommerce_blocks_loaded' ) ) {
			return;
		}
	}
}
WC_NYP_Blocks_Compatibility::init();
