<?php
/**
 * Gift Cards Compatibility
 *
 * @package  WooCommerce Name Your Price/Compatibility
 * @since    3.6.0
 * @version  3.6.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Main WC_NYP_Gift_Cards_Compatibility class
 **/
class WC_NYP_Gift_Cards_Compatibility {

	/**
	 * WC_NYP_Gift_Cards_Compatibility Constructor
	 */
	public static function init() {
		add_action( 'wc_nyp_settings', array( __CLASS__, 'additional_settings' ) );
		add_action( 'woocommerce_before_add_to_cart_form', array( __CLASS__, 'maybe_reorder_display_hooks' ) );
	}

	/**
	 * Additional admin settings.
	 *
	 * @array $settings - The Name Your Price admin settings
	 * @return array
	 */
	public static function additional_settings( $settings ) {

		// Define the new array to insert.
		$new_setting = array(
			'title'   => esc_html__( 'Gift Cards Integration', 'wc_name_your_price' ),
			'desc'    => esc_html__( 'Move price input before gift card form', 'wc_name_your_price' ),
			'id'      => 'woocommerce_nyp_display_before_gift_card',
			'type'    => 'checkbox',
			'default' => 'no',
		);

		// Search for the target array with 'type' => 'sectionend' and 'id' => 'woocommerce_nyp_style_options'.
		$target_index = array_search(
			true,
			array_map(
				function ( $setting ) {
					return isset( $setting['type'], $setting['id'] ) &&
							'sectionend' === $setting['type'] &&
							'woocommerce_nyp_style_options' === $setting['id'];
				},
				$settings
			)
		);

		// Verify the target is found and insert the new setting.
		if ( false !== $target_index ) {
			array_splice( $settings, $target_index, 0, array( $new_setting ) );
		}

		return $settings;
	}

	/**
	 * Re-order display hooks when Gift Cards and NYP together.
	 */
	public static function maybe_reorder_display_hooks() {

		global $product;

		if ( wc_string_to_bool( get_option( 'woocommerce_nyp_display_before_gift_card', 'no' ) ) && WC_GC_Gift_Card_Product::is_gift_card( $product ) ) {
			if ( $product->is_type( WC_Name_Your_Price_Helpers::get_variable_supported_types() ) ) {
				remove_action( 'woocommerce_before_single_variation', array( 'WC_GC_Gift_Card_Product', 'handle_variable_gift_card_form' ), 9 );
				add_action( 'woocommerce_single_variation', array( 'WC_GC_Gift_Card_Product', 'handle_variable_gift_card_form' ), 15 );
			} else {
				remove_action( 'woocommerce_before_add_to_cart_button', array( WC_Name_Your_Price()->display, 'display_price_input' ), 9 );
				add_action( 'woocommerce_before_add_to_cart_button', array( WC_Name_Your_Price()->display, 'display_price_input' ), 5 );
			}
		}
	}
} // End class: do not remove or there will be no more guacamole for you.

WC_NYP_Gift_Cards_Compatibility::init();
