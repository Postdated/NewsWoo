<?php
/**
 * PDF Product Vouchers Compatibility
 *
 * @package  WooCommerce Name Your Price/Compatibility
 * @since    3.6.2
 * @version  3.6.2
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Main WC_NYP_PDF_Vouchers_Compatibility class
 **/
class WC_NYP_PDF_Vouchers_Compatibility {


	/**
	 * WC_NYP_PDF_Vouchers_Compatibility Constructor
	 */
	public static function init() {
		add_filter( 'wc_pdf_product_vouchers_new_voucher_data_before_save', array( __CLASS__, 'set_nyp_voucher_amount_before_save' ), 10, 3 );
	}


	/**
	 * Changes the voucher amount to use the order line item subtotal rather than the original product price.
	 *
	 * @param string[] $args voucher args
	 * @param \WC_Voucher $voucher the voucher object
	 * @param bool $updating true if the voucher is being updated, false if newly created
	 * @return  bool
	 */
	public static function set_nyp_voucher_amount_before_save( $args, $voucher, $updating ) {

		if ( $updating ) {
			return $args;
		}

		if ( empty( $args['order_id'] ) || empty( $args['order_item_id'] ) ) {
			return $args;
		}

		if ( empty( $args['product_id'] ) || ! WC_Name_Your_Price_Helpers::is_nyp( $args['product_id'] ) ) {
			return $args;
		}

		$item = WC_Order_Factory::get_order_item( $args['order_item_id'] );

		if ( ! $item ) {
			return $args;
		}

		$line_tax = $item->get_total_tax( 'edit' );

		$args['product_price'] = $item->get_subtotal( 'edit' ) / $item->get_quantity();
		$args['product_tax']   = $line_tax ? $line_tax / $item->get_quantity() : 0;

		return $args;
	}
} // End class: do not remove or there will be no more guacamole for you.

WC_NYP_PDF_Vouchers_Compatibility::init();
