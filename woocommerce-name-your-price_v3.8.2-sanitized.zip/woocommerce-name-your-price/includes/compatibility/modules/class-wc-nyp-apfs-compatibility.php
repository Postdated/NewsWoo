<?php
/**
 * All Products for WooCommerce Subscriptions (APFS) Compatibility
 *
 * Fixes the broken purchase-type label All Products renders on Name Your Price products.
 * All Products composes the option as sprintf( 'Subscribe for %s', <product price html> ), and
 * NYP's price html is either the whole "Suggested price: $X" sentence or an empty string — giving
 * "Subscribe for Suggested price: $5.00 / month" or "Subscribe for  / month" (GH #241). Since an
 * NYP price is customer-set, no single server-rendered amount is correct.
 *
 * Two layers:
 *   1. Server filter (`wcsatt_price_html_args`) — an amount-agnostic "Subscribe every month" as the
 *      no-JS fallback / initial paint.
 *   2. Frontend script — live-updates the label to "Subscribe for $X / period" as the shopper types
 *      in the NYP field and picks a plan, reflecting exactly what will recur.
 *
 * As of WooCommerce Subscriptions 9.0 APFS is bundled into Subscriptions core, so this surfaces on
 * every store; before 9.0 it required the standalone extension.
 *
 * @package  WooCommerce Name Your Price/Compatibility
 * @since    3.8.1
 * @version  3.8.2
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Main WC_NYP_APFS_Compatibility class
 **/
class WC_NYP_APFS_Compatibility {

	/**
	 * Attach hooks and filters.
	 */
	public static function init() {
		add_filter( 'wcsatt_price_html_args', array( __CLASS__, 'price_html_args' ), 20, 3 );
		add_filter( 'wcsatt_single_add_to_cart_text', array( __CLASS__, 'edit_in_cart_button_text' ), 10, 2 );
	}

	/**
	 * In NYP's edit-in-cart flow, keep NYP's "Update Cart" button label instead of All Products'
	 * sign-up text. All Products derives both the server-rendered button and its JS `data-sign_up_text`
	 * (which relabels the button when the Subscribe option is chosen) from
	 * get_subscription_options_button_text(), which runs through this filter — so overriding it here
	 * corrects both. Detection mirrors WC_Name_Your_Price_Display::single_add_to_cart_text().
	 *
	 * @param  string     $button_text
	 * @param  WC_Product $product
	 * @return string
	 */
	public static function edit_in_cart_button_text( $button_text, $product ) {

		if ( ! WC_Name_Your_Price_Helpers::is_nyp( $product ) ) {
			return $button_text;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['update-price'], $_GET['_nypnonce'] ) && wp_verify_nonce( sanitize_key( $_GET['_nypnonce'] ), 'nyp-nonce' ) ) {
			$updating_cart_key = wc_clean( wp_unslash( $_GET['update-price'] ) );
			if ( WC()->cart && isset( WC()->cart->cart_contents[ $updating_cart_key ] ) ) {
				return apply_filters( 'wc_nyp_single_update_cart_text', __( 'Update Cart', 'wc_name_your_price' ), $product );
			}
		}

		return $button_text;
	}

	/**
	 * Server-side fallback: for an NYP product's option selector, drop the amount (customer-set) and
	 * the dangling "for", so the static label reads "Subscribe every <period>" instead of the broken
	 * "Subscribe for Suggested price: $X / period" / "Subscribe for  / period".
	 *
	 * @param  array      $args        Price-string args passed to All Products' renderer.
	 * @param  WC_Product $product     The product being rendered.
	 * @param  mixed      $scheme_key  The subscription scheme key (unused).
	 * @return array
	 */
	public static function price_html_args( $args, $product, $scheme_key ) {

		if ( ! WC_Name_Your_Price_Helpers::is_nyp( $product ) ) {
			return $args;
		}

		// Only the frontend purchase-type selector — leave catalog/cart/etc. untouched.
		if ( ( isset( $args['context'] ) ? $args['context'] : '' ) !== 'prompt' ) {
			return $args;
		}

		// With the amount suppressed, All Products' renderer fills %s with the billing-period phrase
		// ("every month") — see Price_String_Renderer::render() in Subscriptions; revisit these strings if
		// that ever changes. "for" and "from" get the same string on purpose: NYP prices are
		// shopper-entered, so the for/from distinction has no meaning here.
		$args['subscription_price']  = false;
		/* translators: %s: billing-period phrase rendered by All Products, e.g. "every month" */
		$args['subscribe_for_html']  = _x( 'Subscribe %s', 'NYP + All Products subscribe option', 'wc_name_your_price' );
		/* translators: %s: billing-period phrase rendered by All Products, e.g. "every month" */
		$args['subscribe_from_html'] = _x( 'Subscribe %s', 'NYP + All Products subscribe option', 'wc_name_your_price' );

		return $args;
	}

	/**
	 * Live label: reflect the entered NYP amount + the selected plan's billing cycle.
	 *
	 * Attaches to NYP's own `woocommerce-nyp` frontend script (so it loads only where NYP loads) and
	 * listens for NYP's `wc-nyp-updated` event plus changes to the All Products plan selector.
	 * Formatting reuses what NYP already ships — `wc_nyp_format_price()` and
	 * `woocommerce_nyp_params.i18n_subscription_string` — so no currency handling lives here. Period
	 * labels come from Subscriptions' own translations (`wcs_get_subscription_period_strings()`).
	 * 
	 * @deprecated 3.8.2 - Reverted, back to not dynamically updating the label.
	 */
	public static function inline_script() {

		wc_deprecated_function( __METHOD__, '3.8.2', 'This feature was reverted and is no longer needed.' );

		// Localized period labels, keyed [interval][period] (Subscriptions supports intervals 1-6).
		$periods = array();
		if ( function_exists( 'wcs_get_subscription_period_strings' ) ) {
			for ( $interval = 1; $interval <= 6; $interval++ ) {
				$periods[ $interval ] = wcs_get_subscription_period_strings( $interval );
			}
		}

		wp_localize_script(
			'woocommerce-nyp',
			'wc_nyp_apfs_params',
			array(
				/* translators: %s: price + billing period, e.g. "$6.00 / month" */
				'subscribe_for' => _x( 'Subscribe for %s', 'NYP + All Products subscribe option', 'wc_name_your_price' ),
				'periods'       => $periods,
			)
		);

		wp_add_inline_script( 'woocommerce-nyp', self::get_script() );
	}

	/**
	 * The label-updater script. Kept as a nowdoc so no PHP interpolation leaks in.
	 *
	 * @return string
	 */
	private static function get_script() {
		return <<<'JS'
( function ( $ ) {
	var P = window.wc_nyp_apfs_params || {};
	var N = window.woocommerce_nyp_params || {};

	if ( typeof wc_nyp_format_price !== 'function' || typeof wc_nyp_unformat_number !== 'function' ) { return; }

	// Localized "month" / "2 months" etc. for the selected plan.
	function periodLabel( scheme ) {
		var interval = ( scheme && scheme.interval ) ? parseInt( scheme.interval, 10 ) || 1 : 1;
		var period   = ( scheme && scheme.period ) ? scheme.period : 'month';
		return ( P.periods && P.periods[ interval ] && P.periods[ interval ][ period ] ) ? P.periods[ interval ][ period ] : period;
	}

	function schemeOf( radio ) {
		var d;
		try { d = JSON.parse( radio.getAttribute( 'data-custom_data' ) || 'null' ); } catch ( e ) { d = null; }
		return ( d && d.subscription_scheme && d.subscription_scheme.period ) ? d.subscription_scheme : null;
	}

	// The plan the shopper currently has selected. The plan dropdown's value (multi-plan) wins, so the
	// label never depends on All Products having synced the radios yet; else the checked radio; else
	// the first available.
	function activeScheme( wrap ) {
		var dropdown = wrap.querySelector( '.wcsatt-options-product-dropdown' );
		if ( dropdown && dropdown.value ) {
			var key   = ( window.CSS && CSS.escape ) ? CSS.escape( dropdown.value ) : dropdown.value;
			var match = wrap.querySelector( 'input[name^="convert_to_sub_"][value="' + key + '"]' );
			var fromDropdown = match ? schemeOf( match ) : null;
			if ( fromDropdown ) { return fromDropdown; }
		}
		var chosen = null, first = null;
		wrap.querySelectorAll( 'input[name^="convert_to_sub_"]' ).forEach( function ( r ) {
			var s = schemeOf( r );
			if ( s ) {
				if ( ! first ) { first = s; }
				if ( r.checked ) { chosen = s; }
			}
		} );
		return chosen || first;
	}

	function currentPrice() {
		var input = document.querySelector( 'input[name="nyp"]' );
		if ( ! input || input.value === '' ) { return NaN; }
		// NYP formats the field with the store's separators — unformat before parsing.
		return parseFloat( wc_nyp_unformat_number( input.value ) );
	}

	function update() {
		var price = currentPrice();
		document.querySelectorAll( '.wcsatt-options-wrapper' ).forEach( function ( wrap ) {
			var action = wrap.querySelector( '.wcsatt-options-prompt-label-subscription .wcsatt-options-prompt-action' );
			if ( ! action ) { return; }

			// Remember the server-rendered label ("Subscribe every month") to fall back to. Kept and
			// restored as text — never re-parsed as HTML.
			if ( ! action.hasAttribute( 'data-nyp-original' ) ) {
				action.setAttribute( 'data-nyp-original', action.textContent );
			}

			if ( ! isNaN( price ) && price > 0 ) {
				var pricePerPeriod = ( N.i18n_subscription_string || '%price / %period' )
					.replace( '%price', wc_nyp_format_price( price ) )
					.replace( '%period', periodLabel( activeScheme( wrap ) ) );
				action.textContent = ( P.subscribe_for || 'Subscribe for %s' ).replace( '%s', pricePerPeriod );
			} else {
				action.textContent = action.getAttribute( 'data-nyp-original' );
			}
		} );
	}

	// NYP's own signal that the price changed (carries the validated user_price).
	$( '.cart' ).on( 'wc-nyp-updated', '.nyp', update );
	// Fallbacks: typing directly, and switching plan/period in the All Products selector.
	$( document ).on( 'input', 'input[name="nyp"]', update );
	$( document ).on( 'change', '.wcsatt-options-product-dropdown, input[name^="convert_to_sub_"]', update );
	$( update );
} )( jQuery );
JS;
	}

} // End class: do not remove or there will be no more guacamole for you.

WC_NYP_APFS_Compatibility::init();
