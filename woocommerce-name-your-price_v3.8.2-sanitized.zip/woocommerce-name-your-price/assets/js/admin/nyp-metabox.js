/**
 * Script for editing the prices in the product data metabox.
 *
 * @package WooCommerce Name Your Price/Admin/Scripts
 */
(function($) {

	var NYPMetabox = {
		priceFields: [
			'._regular_price_field',
			'._sale_price_field',
		],
		addClasstoRegularPrice: function() {
			$( '.options_group.pricing' ).find( this.priceFields.join( ', ' ) ).addClass( 'hide_if_nyp' );
		},
		addClasstoVariablePrice: function() {
			$( '.woocommerce_variation .variable_pricing' ).addClass( 'hide_if_nyp' );
		},
		enableDisableSubscriptionLength: function( disable ) {
			if ( disable ) {
				$( '#_subscription_length' ).prop( 'disabled', true ).css( 'background', '#CCC' );
			} else {
				$( '#_subscription_length' ).prop( 'disabled', false ).css( 'background', '#FFF' );
			}
		},
		enableDisableSubscriptionPeriod: function( disable ) {
			var $subscription_period = $( '#_subscription_period_interval, #_subscription_period' );
			if ( disable ) {
				$subscription_period.prop( 'disabled', true ).css( 'background','#CCC' );
			} else {
				$subscription_period.prop( 'disabled', false ).css( 'background', '#FFF' );
			}
		},
		enableDisableSubscriptionPrice: function( enable ) {
			if ( enable ) {
				$( '#_subscription_price' ).prop( 'disabled', true ).css( 'background', '#CCC' );
			} else {
				$( '#_subscription_price' ).prop( 'disabled', false ).css( 'background', '#FFF' );
			}
		},
		moveNYPmetaFields: function() {
			if ( ! $( '.options_group.show_if_nyp' ).hasClass( 'nyp_moved' ) ) {
				$( '.options_group.show_if_nyp' ).insertBefore( '.options_group.pricing:first' ).addClass( 'nyp_moved' );
			}
		},
		moveNYPvariationFields: function() {
			$( '#variable_product_options .variable_nyp_pricing' ).not( '.nyp_moved' ).each(
				function() {
					$( this ).insertAfter( $( this ).siblings( '.variable_pricing' ).first() ).addClass( 'nyp_moved' );
				}
			);
		},
		showHideNYPelements: function() {
			var product_type = $( 'select#product-type' ).val();
			var is_nyp       = $( '#_nyp' ).prop( 'checked' );

			$('#woocommerce-product-data').toggleClass( 'is_nyp', is_nyp && woocommerce_nyp_metabox.simple_types.indexOf( product_type ) > -1 );

			switch ( true ) {
				case 'subscription' === product_type:
					this.enableDisableSubscriptionPrice( is_nyp );
					var is_variable_billing = $( '#_variable_billing' ).prop( 'checked' );
					this.showHideNYPvariablePeriods( is_variable_billing );
					this.enableDisableSubscriptionPeriod( is_nyp && is_variable_billing );
					this.enableDisableSubscriptionLength( is_nyp && is_variable_billing );
					break;
				case 'variable-subscription' === product_type:
					this.moveNYPvariationFields();
					this.showHideNYPmetaforVariableSubscriptions();
					break;
				case woocommerce_nyp_metabox.simple_types.indexOf( product_type ) > -1:
					this.showHideNYPvariablePeriods( false );
					break;
				case woocommerce_nyp_metabox.variable_types.indexOf( product_type ) > -1:
					this.moveNYPvariationFields();
					this.showHideNYPmetaforVariableProducts();
					break;
			}
		},
		showHideNYPmetaforVariableProducts: function() {

			$( '.variation_is_nyp' ).each(
				function() {
					var product_type = $( 'select#product-type' ).val();
					var is_nyp       = $( this ).prop( 'checked' );
					$( this ).closest( '.woocommerce_variation' ).toggleClass( 'is_nyp', is_nyp && woocommerce_nyp_metabox.variable_types.indexOf( product_type ) > -1 );
				}
			);

		},
		showHideNYPmetaforVariableSubscriptions: function() {

			$( '.variation_is_nyp' ).each(
				function() {
					var $variable_pricing            = $( this ).closest( '.woocommerce_variation' ).find( '.variable_pricing' );
					var $variable_subscription_price = $( this ).closest( '.woocommerce_variation' ).find( '.wc_input_subscription_price' );

					var $nyp_pricing = $( this ).closest( '.woocommerce_variation' ).find( '.variable_nyp_pricing' );

					if ( $( this ).prop( 'checked' ) ) {
							$nyp_pricing.show();
							$variable_subscription_price.prop( 'disabled', true ).css( 'background','#CCC' );
							$variable_pricing.children().not( '.show_if_variable-subscription' ).hide();
					} else {
						$nyp_pricing.hide();
						$variable_subscription_price.prop( 'disabled', false ).css( 'background', '#FFF' );
						$variable_pricing.children().not( '.hide_if_variable-subscription' ).show();
					}

				}
			);

		},
		showHideNYPprices: function( show, restore ) {
			// For simple and sub types we'll want to restore the regular price inputs.
			restore = typeof restore !== 'undefined' ? restore : false;
			if ( show ) {
				$( '.show_if_nyp' ).show();
				$( '.hide_if_nyp' ).hide();
			} else {
				$( '.show_if_nyp' ).hide();
				if ( restore ) {
					$( '.hide_if_nyp' ).show();
				}
			}
		},
		showHideNYPvariableMeta: function() {
			if ( 'variable-subscription' === $( '#product-type' ).val() ) {
				this.showHideNYPmetaforVariableSubscriptions();
			} else {
				this.showHideNYPmetaforVariableProducts();
			}
		},
		showHideNYPvariablePeriods: function( show ) {
			var $variable_periods = $( '.show_if_variable_billing' );
			if ( show ) {
				$variable_periods.show();
			} else {
				$variable_periods.hide();
			}
		}

	}; // End NYPMetabox.

	// Magically move the simple inputs into the same location as the normal pricing section.
	if ( $( '.options_group.pricing' ).length > 0) {
		NYPMetabox.moveNYPmetaFields();
		NYPMetabox.addClasstoRegularPrice();
		NYPMetabox.showHideNYPelements();
	}

	// Adjust fields when the product type is changed.
	$( 'body' ).on(
		'woocommerce-product-type-change',
		function() {
			NYPMetabox.showHideNYPelements();
		}
	);

	// Adjust the fields when NYP status is changed.
	$( 'input#_nyp' ).on(
		'change',
		function() {
			NYPMetabox.showHideNYPelements();
		}
	);

	// Adjust the fields when variable billing period status is changed.
	$( '#_variable_billing' ).on(
		'change',
		function() {
			NYPMetabox.showHideNYPvariablePeriods( this.checked );
			NYPMetabox.enableDisableSubscriptionPeriod( this.checked );
			NYPMetabox.enableDisableSubscriptionLength( this.checked );
		}
	);

	// WC 2.4 compat: handle variable products on load.
	$( '#woocommerce-product-data' ).on(
		'woocommerce_variations_loaded',
		function() {
			NYPMetabox.addClasstoVariablePrice();
			NYPMetabox.moveNYPvariationFields();
			NYPMetabox.showHideNYPvariableMeta();
		}
	);

	// When a variation is added.
	$( '#variable_product_options' ).on(
		'woocommerce_variations_added',
		function() {
			NYPMetabox.addClasstoVariablePrice();
			NYPMetabox.moveNYPvariationFields();
			NYPMetabox.showHideNYPvariableMeta();
		}
	);

	// Hide/display variable nyp prices on single nyp checkbox change.
	$( '#variable_product_options' ).on(
		'change',
		'.variation_is_nyp',
		function() {
			NYPMetabox.showHideNYPvariableMeta();
		}
	);

	// Hide/display variable nyp prices on bulk nyp checkbox change.
	$( 'select.variation_actions' ).on(
		'woocommerce_variable_bulk_nyp_toggle',
		function() {
			NYPMetabox.showHideNYPvariableMeta();
		}
	);

	/*
	* Bulk Edit callbacks
	*/
	// WC 2.4+ variation bulk edit handling.
	$( 'select.variation_actions' ).on(
		'variation_suggested_price_ajax_data variation_suggested_price_increase_ajax_data variation_suggested_price_decrease_ajax_data variation_min_price_ajax_data variation_min_price_increase_ajax_data variation_min_price_decrease_ajax_data variation_maximum_price_ajax_data variation_maximum_price_increase_ajax_data variation_maximum_price_decrease_ajax_data',
		function(event, data) {

			var variation_action = $( this ).val();
			var value;

			switch ( variation_action ) {
				case 'variation_suggested_price':
				case 'variation_min_price':
				case 'variation_maximum_price':
					value = window.prompt( woocommerce_nyp_metabox.enter_value );
					// Unformat.
					value = accounting.unformat( value, woocommerce_admin.mon_decimal_point );
					break;
				case 'variation_suggested_price_increase':
				case 'variation_suggested_price_decrease':
				case 'variation_min_price_increase':
				case 'variation_min_price_decrease':
				case 'variation_maximum_price_increase':
				case 'variation_maximum_price_decrease':
					value = window.prompt( woocommerce_nyp_metabox.price_adjust );

					// Is it a percentage change?
					data.percentage = value.indexOf( '%' ) >= 0 ? 'yes' : 'no';

					// Unformat.
					value = accounting.unformat( value, woocommerce_admin.mon_decimal_point );

			}

			if ( null !== value ) {
				data.value = value;
			}
			return data;
		}
	);

})( jQuery ); // End.
