/**
 * External dependencies
 */

import { addFilter } from '@wordpress/hooks';
import { __, _x } from '@wordpress/i18n';

/**
 * Local imports
 */
import Report from './report';

addFilter(
	'woocommerce_admin_reports_list',
	'analytics/nyp',
	( reports ) => {
		return [
			...reports,
			{
				report: 'nyp',
				title:  _x( 'Name Your Price', 'analytics report table', 'wc_name_your_price' ),
				component: Report,
				navArgs: {
					id: 'wc-nyp-report',
				},
			},
		];
	}
);
