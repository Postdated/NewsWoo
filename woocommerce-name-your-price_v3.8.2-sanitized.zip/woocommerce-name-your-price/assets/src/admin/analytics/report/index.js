/**
 * External dependencies
 */
import { Fragment } from '@wordpress/element';
import { __ } from '@wordpress/i18n';

/**
 * WooCommerce dependencies
 */
//import { ReportFilters, TableCard } from '@woocommerce/components';

const Report = ( { path, query } ) => {
	return (
		<Fragment>
			<p>I hate webpack</p>
			<p>It truely is the worst</p>
		</Fragment>
	);
};

export default Report;